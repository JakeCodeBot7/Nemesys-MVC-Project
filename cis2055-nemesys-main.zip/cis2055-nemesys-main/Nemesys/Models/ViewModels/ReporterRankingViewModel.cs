﻿namespace Nemesys.Models.ViewModels
{
    public class ReporterRankingViewModel
    {
        public string ReporterAlias { get; set; }
        public string ReporterEmail { get; set; }
        public int ReportCount { get; set; }
    }
}
