﻿namespace Nemesys.Models.ViewModels
{
    public class ReportStatusViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
