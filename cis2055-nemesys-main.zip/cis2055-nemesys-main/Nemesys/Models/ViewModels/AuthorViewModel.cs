﻿namespace Nemesys.Models.ViewModels
{
    public class AuthorViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }

    }
}
